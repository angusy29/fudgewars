declare let DEBUG: boolean;
declare let DEFAULT_GAME_WIDTH: number;
declare let DEFAULT_GAME_HEIGHT: number;
declare let MAX_GAME_WIDTH: number;
declare let MAX_GAME_HEIGHT: number;
declare let SCALE_MODE: string;
declare let GOOGLE_WEB_FONTS: string[];
declare let SOUND_EXTENSIONS_PREFERENCE: string[];
